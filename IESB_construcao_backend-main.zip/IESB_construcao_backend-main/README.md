# IESB_construcao_backend

## CONFIGURAÇÕES VSCODE

Extensões:

- Code Runner
- Material Icon Theme
- Codeium
- intelliCode
- npm Intellisense
- Path Intellisense
- DotENV
