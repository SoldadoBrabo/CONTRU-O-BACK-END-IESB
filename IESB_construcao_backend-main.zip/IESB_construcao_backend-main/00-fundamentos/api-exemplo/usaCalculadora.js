const calculadora = require('./Calculadora')

console.log(calculadora.somar(2,2))
console.log(calculadora.subtrair(10,5))
console.log(calculadora.multiplicar(10,10))
console.log(calculadora.dividir(100,10))