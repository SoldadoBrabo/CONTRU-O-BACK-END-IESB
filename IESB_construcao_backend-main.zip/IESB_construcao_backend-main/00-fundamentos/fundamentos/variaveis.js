const nome = "Lucas Garcia"
const nota = 5

let aprovado = false

if (nota >= 6) {
    aprovado = true
}

console.log("Nome:", nome)
console.log("Nota:", nota)
console.log("Aprovado:", aprovado)

